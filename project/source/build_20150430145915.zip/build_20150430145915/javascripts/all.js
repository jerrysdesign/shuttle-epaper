$(document).ready(function() {
  var lesstext, moretext;

  moretext = '顯示全文';
  lesstext = '隱藏全文';
  $('.morelink').click(function() {
    if ($(this).hasClass('less')) {
      $(this).removeClass('less');
      $(this).html(moretext);
    } else {
      $(this).addClass('less');
      $(this).html(lesstext);
    }
    $(this).prev().toggle();
    return false;
  });
});
